# Tasyir bmd
نظام نقطة بيع ومخزون: **تطبيق أندرويد** + **برنامج حاسوب (Windows)** بمزامنة سحابية لحظية (Firebase) ونسخة كاملة اختيارية على Google Drive.

ابدأ من **[SETUP-AR.md](SETUP-AR.md)**.

```
desktop/   Electron (v2.3.0)
android/   Kotlin + WebView (v2.3 / code 106)
firebase-rules.json
.github/workflows/  desktop-build.yml · android-build.yml
```
