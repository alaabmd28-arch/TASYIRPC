/* Tasyir bmd — تصميم سطح المكتب (شكل فقط): الرئيسية بالبلاطات + البيع المباشر الاحترافي.
   لا يغيّر أي منطق: كل الأزرار تستدعي نفس الدوال الأصلية، وتبقى المعرّفات التي تعتمد عليها (q, rs, bs, cartbox, cn, tv, pbtn). */
(function () {
  'use strict';
  if (!window.__tasyirNative) return;
  var mq = matchMedia('(min-width:900px)'), wide = function () { return mq.matches; };
  var Lx = function (a, f, e) { return L(a, f, e); };
  var _dash = VIEWS.dash, _pos = VIEWS.pos, _R = R;

  /* ---------------- الرئيسية: بلاطات مجمّعة ---------------- */
  function tile(cls, icon, label, fn, big) {
    return '<button class="tl ' + cls + (big ? ' w' : '') + '" onclick="' + fn + '"><span class="tli">' + ic(icon, big ? 48 : 40) + '</span><span class="tn">' + label + '</span></button>';
  }
  function group(title, tiles) { return '<section class="hg"><h4>' + title + '</h4><div class="tgrid">' + tiles.join('') + '</div></section>'; }
  function home() {
    var d = new Date(), shop = (ST().shop && ST().shop.name) || db.shop || '';
    var sales = group(Lx('المبيعات', 'Ventes', 'Sales'), [
      tile('c-coral', 'cart', Lx('البيع المباشر', 'Vente directe', 'Direct sale'), "go('pos')", 1),
      tile('c-blue', 'users', Lx('الزبائن', 'Clients', 'Customers'), "go('cust')"),
      tile('c-rose', 'book', Lx('الديون', 'Dettes', 'Debts'), "go('dbt')"),
      tile('c-purple', 'trend', Lx('التحليلات', 'Analyses', 'Analytics'), "go('ana')"),
      tile('c-cyan', 'chart', Lx('متابعة متجر', 'Suivi boutique', 'Follow shop'), "go('fol')")]);
    var buy = group(Lx('المشتريات والموردون', 'Achats & fournisseurs', 'Purchases & suppliers'), [
      tile('c-green', 'truck', Lx('الموردون', 'Fournisseurs', 'Suppliers'), "go('sup')", 1),
      tile('c-amber', 'briefcase', Lx('العمال والرواتب', 'Employés & salaires', 'Workers & payroll'), "go('wrk')"),
      tile('c-orange', 'wallet', Lx('المصاريف', 'Dépenses', 'Expenses'), "go('exp')"),
      tile('c-slate', 'calc', Lx('حاسبة رأس المال', 'Calcul du capital', 'Capital calculator'), "go('cap')"),
      tile('c-teal2', 'sliders', Lx('الإعدادات', 'Réglages', 'Settings'), "go('set')")]);
    var prod = group(Lx('المنتجات', 'Produits', 'Products'), [
      tile('c-teal', 'package', Lx('قائمة المنتجات', 'Liste des produits', 'Product list'), "go('prod')", 1),
      tile('c-cyan2', 'plus', Lx('منتج جديد', 'Nouveau produit', 'New product'), "pForm()"),
      tile('c-green2', 'boxes', Lx('المخزون', 'Stock', 'Stock'), "go('inv')"),
      tile('c-blue2', 'scan', Lx('الماسح الضوئي', 'Lecteur code-barres', 'Barcode scanner'), "go('set');sub='scanner';R()"),
      tile('c-purple2', 'cloud', Lx('المزامنة السحابية', 'Synchro cloud', 'Cloud sync'), "go('set');sub='cloud';R()")]);
    return '<div class="homebar"><div><div class="hn">' + d.toLocaleDateString(LC(), { weekday: 'long' }) + '</div><div class="k">' + d.toLocaleDateString(LC(), { year: 'numeric', month: 'long', day: 'numeric' }) + '</div></div>' +
      '<div class="bar"><button class="b s" onclick="go(\'set\');sub=\'backup\';R()">' + ic('save') + ' ' + t('bk') + '</button></div></div>' +
      (window.TDcloud ? TDcloud.banner() : '') + '<div class="home">' + sales + buy + prod + '</div>' +
      '<h4 class="hsum">' + Lx('ملخص المتجر', 'Résumé de la boutique', 'Shop summary') + '</h4>';
  }
  VIEWS.dash = function () { return wide() ? home() + '<div class="homesum">' + _dash() + '</div>' : _dash(); };

  /* ---------------- البيع المباشر ---------------- */
  var act = function (icn, label, fn) { return '<button class="b s" onclick="' + fn + '">' + ic(icn) + '<span>' + label + '</span></button>'; };
  VIEWS.pos = function () {
    if (!wide()) return _pos();
    return '<div class="posx"><section class="px-main">' +
      '<div class="px-search"><span class="px-si">' + ic('search') + '</span>' +
      '<input id="q" type="search" enterkeyhint="search" inputmode="search" placeholder="' + t('search') + '" aria-label="' + esc(t('search')) + '" oninput="find(this.value)" onkeydown="if(event.key===\'Enter\')enter(this.value)" autocomplete="off">' +
      '<button class="b px-scan" aria-label="' + esc(t('scan')) + '" onclick="scan(posScan,1)">' + ic('scan') + '</button><div id="rs"></div></div>' +
      '<div id="bs"></div>' +
      '<div class="px-cart"><div class="px-head"><span>' + Lx('المنتج', 'Produit', 'Item') + '</span><span>' + t('qty') + '</span><span>' + Lx('المبلغ', 'Montant', 'Amount') + '</span><span></span></div><div id="cartbox"></div></div>' +
      '</section><aside class="px-side">' +
      '<div class="tot"><div class="ti">' + ic('cart') + '</div><div><div class="k2">' + t('total') + '</div><div class="tv" id="tv" data-v="0">' + M(0) + '</div></div></div>' +
      tiersBar() + '<div class="px-cn" id="cn"></div>' +
      '<div class="px-acts">' + act('user', Lx('الزبون', 'Client', 'Customer'), 'custSel()') + act('tag', t('disc'), 'discF()') + act('file', t('note'), 'noteF()') +
      act('pause', Lx('تعليق', 'Attente', 'Hold'), 'holdCart()') + act('play', Lx('استئناف', 'Reprendre', 'Resume') + (db.held.length ? ' (' + db.held.length + ')' : ''), 'heldList()') +
      act('eraser', Lx('مسح', 'Vider', 'Clear'), "cart=[];cdisc=0;cnote='';ov.innerHTML='';cartUp()") + '</div>' +
      '<button class="b pay" id="pbtn" onclick="payUI()">' + Lx('الدفع', 'Payer', 'Pay') + '</button></aside></div>';
  };

  /* ---------------- زر الإعدادات في الشريط الجانبي + إعادة الرسم عند تغيّر العرض ---------------- */
  R = function () {
    _R.apply(this, arguments);
    try { document.body.classList.toggle('dsk', wide()); if (wide()) { var n = document.getElementById('nv'); if (n) n.insertAdjacentHTML('beforeend', '<button class="' + (tab === 'set' ? 'on' : '') + '" onclick="go(\'set\')"><span class="ni">' + ic('sliders') + '</span><span>' + t('set') + '</span></button>'); } } catch (e) { /* لا شيء */ }
  };
  var ch = function () { try { R(); } catch (e) { /* لا شيء */ } };
  if (mq.addEventListener) mq.addEventListener('change', ch);
  ch();
})();
