'use strict';
/* يشغّل main.js الحقيقي مع electron وهمي: يكشف أخطاء التسجيل/الظلال (مثل sync.status) دون الحاجة لـ Electron. */
const Module = require('module'), path = require('path'), os = require('os'), fs = require('fs'), assert = require('assert');
const handles = {}, ons = {}, sends = [], fetched = [];
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'tasyir-main-'));
let readyCb;
const fakeWin = { webContents: { on() {}, setWindowOpenHandler() {}, send: (c, m) => sends.push([c, m]), getZoomFactor: () => 1, setZoomFactor() {} }, once() {}, on() {}, loadURL() {}, maximize() {}, show() {}, getNormalBounds: () => ({}), isMaximized: () => false, isDestroyed: () => false };
const electron = {
  app: { requestSingleInstanceLock: () => true, quit() {}, on() {}, getPath: () => tmp, isPackaged: true, whenReady: () => ({ then: (f) => { readyCb = f; } }) },
  BrowserWindow: Object.assign(function () { return fakeWin; }, { getAllWindows: () => [fakeWin] }),
  ipcMain: { handle: (c, f) => { handles[c] = f; }, on: (c, f) => { ons[c] = f; } },
  dialog: {}, shell: { openExternal() {} }, Menu: { setApplicationMenu() {} },
  protocol: { registerSchemesAsPrivileged() {}, handle() {} },
  session: { defaultSession: { setPermissionRequestHandler() {}, setPermissionCheckHandler() {}, setDevicePermissionHandler() {}, on() {} } },
  net: { fetch: async (u, o) => { fetched.push([u, o]); return { status: 200, text: async () => '{"ok":1}' }; } },
};
const orig = Module._load; Module._load = function (r, ...a) { return r === 'electron' ? electron : orig.call(this, r, ...a); };
require('../main.js'); Module._load = orig;
(async () => {
  const ok = (m) => console.log('PASS ' + m);
  await readyCb(); ok('main.js يبدأ دون أخطاء مع electron وهمي');
  // المزامنة المحلية (كان يفشل بسبب ظلّ المتغير sync)
  let st = await handles['sync:status'](); assert.strictEqual(st.enabled, false); assert.ok(Array.isArray(st.hosts)); ok('sync:status يعمل');
  st = await handles['sync:config']({}, { enable: true, K: 'a'.repeat(64) }); assert.strictEqual(st.enabled, true, st.error); assert.ok(/^[0-9a-f]{32}$/.test(st.token)); ok('sync:config يشغّل الخادم ويولّد الرمز');
  st = await handles['sync:config']({}, { enable: false }); assert.strictEqual(st.enabled, false);
  // PIN المتزامن
  const ev = {}; ons['pin:info'](ev); assert.deepStrictEqual(ev.returnValue, { on: false, timeout: 60 }); ok('pin:info');
  // http:fetch
  let r = await handles['http:fetch']({}, { url: 'https://tasyir-bmd-default-rtdb.europe-west1.firebasedatabase.app/s/x/r.json', method: 'PATCH', headers: { 'Content-Type': 'application/json', 'bad header': 'x' }, body: '{}' });
  assert.strictEqual(r.status, 200); assert.strictEqual(fetched[0][1].method, 'PATCH'); assert.ok(!('bad header' in fetched[0][1].headers)); ok('http:fetch يمرّر Firebase');
  r = await handles['http:fetch']({}, { url: 'https://oauth2.googleapis.com/token', method: 'POST', body: 'a=b' }); assert.strictEqual(r.status, 200);
  for (const bad of ['http://x.firebaseio.com/a', 'https://evil.com/a', 'https://firebaseio.com.evil.com/a', 'https://oauth2.googleapis.com.evil.com/', 'file:///etc/passwd']) {
    r = await handles['http:fetch']({}, { url: bad }); assert.strictEqual(r.status, 0, bad); assert.ok(/not allowed|Invalid/i.test(r.text), bad + ' -> ' + r.text);
  }
  r = await handles['http:fetch']({}, { url: 'https://www.googleapis.com/drive/v3/files', method: 'TRACE' }); assert.strictEqual(r.status, 0); ok('http:fetch يرفض المضيفات الأخرى والبروتوكولات والطرق الغريبة');
  console.log('main mock OK'); process.exit(0);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
