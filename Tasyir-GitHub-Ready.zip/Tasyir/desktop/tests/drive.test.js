'use strict';
const assert = require('assert');
const SC = require('../app/js/sync-core.js'), CC = require('../app/js/cloud-core.js');
const { start } = require('./mockgoogle.js');
const CODE = 'ABCD-EFGH-JKLM-NPQR-STUV-WXYZ';
const mkdb = () => ({ products: [], customers: [], sales: [], ledger: [], expenses: [], suppliers: [], supLedger: [], workers: [], capSessions: [], settings: {}, seq: 0 });
const httpf = async (r) => { try { const x = await fetch(r.url, { method: r.method, headers: r.headers, body: r.body }); return { status: x.status, text: await x.text() }; } catch (e) { return { status: 0, text: String(e) }; } };
let tick = 10000; const clock = () => (tick += 1000);
(async () => {
  const G = await start(), ok = (m) => console.log('PASS ' + m);
  const mk = (dev) => { const d = mkdb(); let st = {}; const dr = new CC.Drive({ code: CODE, db: () => d, http: httpf, dev, now: clock, g: G.g, cfg: { clientId: 'cid', clientSecret: 'sec' }, store: { get: () => st, set: (x) => { st = x; } } }); return { d, dr, st: () => st }; };
  const A = mk('A'), B = mk('B');
  // تسجيل الدخول (device flow)
  const a = await A.dr.begin(); assert.strictEqual(a.user_code, 'ABCD-EFGH');
  assert.strictEqual(await A.dr.poll(a), 'pending'); assert.strictEqual(await A.dr.poll(a), 'pending'); assert.strictEqual(await A.dr.poll(a), 'ok'); assert.ok(A.dr.connected()); ok('تسجيل الدخول عبر الرمز (pending ثم ok)');
  const b = await B.dr.begin(); G.log.length = 0; await B.dr.poll(b).catch(() => 0); await B.dr.poll(b).catch(() => 0); await B.dr.poll(b); assert.ok(B.dr.connected());
  // بيانات اعتماد خاطئة
  const bad = new CC.Drive({ code: CODE, db: mkdb, http: httpf, dev: 'X', g: G.g, cfg: { clientId: 'zzz', clientSecret: 'sec' }, store: { get: () => ({}), set() {} } }); await assert.rejects(() => bad.begin(), /invalid_client/); ok('client id خاطئ يُرفض برسالة واضحة');
  const none = new CC.Drive({ code: CODE, db: mkdb, http: httpf, dev: 'X', g: G.g, cfg: {}, store: { get: () => ({}), set() {} } }); await assert.rejects(() => none.begin(), /no-client/); ok('بلا client id يُكتشف');
  // مزامنة بطيئة
  A.d.products.push({ id: 'p1', name: 'حليب', bc: '1', price: 80 }); A.d.sales.push({ id: 's1', total: 80, lines: [{ pid: 'p1', q: 1 }] }); A.d.seq = 9;
  let r = await A.dr.sync(); assert.strictEqual(r.uploaded, 1); assert.strictEqual(Object.keys(G.files).length, 1);
  r = await B.dr.sync(); assert.strictEqual(r.merged >= 2, true); assert.strictEqual(B.d.products[0].name, 'حليب'); assert.strictEqual(B.d.seq, 9); ok('A رفع لقطة وB دمجها (منتج + فاتورة + seq)');
  B.d.products[0].price = 99; B.d.expenses.push({ id: 'e1', amt: 5 });
  await B.dr.sync(); assert.strictEqual(Object.keys(G.files).length, 2); await A.dr.sync();
  assert.strictEqual(A.d.products[0].price, 99); assert.strictEqual(A.d.expenses.length, 1); ok('تعديل B وصل إلى A عبر Drive');
  // لا رفع بلا تغيير
  G.log.length = 0; r = await A.dr.sync(); assert.strictEqual(r.uploaded, 0); assert.ok(!G.log.some((l) => l.startsWith('POST /upload') || l.startsWith('PATCH') || l.startsWith('DELETE'))); ok('بلا تغيير لا رفع');
  // إعادة الرفع لا تُكثّر الملفات (ننشئ الجديد ونحذف القديم) ولا نستعمل PATCH
  A.d.products.push({ id: 'pz', name: 'z', bc: 'zz' }); G.log.length = 0; await A.dr.sync(); assert.strictEqual(Object.keys(G.files).length, 2); assert.ok(!G.log.some((l) => l.startsWith('PATCH'))); ok('إعادة الرفع: ملف واحد لكل جهاز وبلا PATCH');
  A.d.products = A.d.products.filter((p) => p.id !== 'pz'); await A.dr.sync();
  // حذف
  A.d.products.length = 0; await A.dr.sync(); await B.dr.sync(); assert.strictEqual(B.d.products.length, 0); ok('الحذف انتقل عبر Drive');
  // gap: رفع محدود بالفاصل
  A.d.products.push({ id: 'p9', name: 'x', bc: '9' }); r = await A.dr.sync({ gap: 3600e3 }); assert.strictEqual(r.uploaded, 0); r = await A.dr.sync({ force: true }); assert.strictEqual(r.uploaded, 1); ok('الفاصل الزمني + المزامنة القسرية');
  // الإلغاء من حساب Google
  G.revoke(); A.st().exp = 0; await assert.rejects(() => A.dr.sync(), /revoked/); assert.ok(!A.dr.connected()); ok('إلغاء الإذن يفصل الحساب بوضوح');
  G.close(); console.log('drive tests OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
