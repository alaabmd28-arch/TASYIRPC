'use strict';
const assert = require('assert');
const SC = require('../app/js/sync-core.js');
const CC = require('../app/js/cloud-core.js');
const { start } = require('./mockfb.js');
const CODE = 'ABCD-EFGH-JKLM-NPQR-STUV-WXYZ';
const mkdb = () => ({ products: [], customers: [], sales: [], ledger: [], expenses: [], suppliers: [], supLedger: [], workers: [], capSessions: [], settings: {}, seq: 0, shop: 'متجر' });
const httpf = async (r) => { try { const x = await fetch(r.url, { method: r.method, headers: r.headers, body: r.body }); return { status: x.status, text: await x.text() }; } catch (e) { return { status: 0, text: String(e) }; } };
let tick = 1000; const clock = () => (tick += 7);
function dev(name, fb) { const d = mkdb(); const c = new CC.Firebase({ fb, code: CODE, db: () => d, http: httpf, dev: name, now: clock }); return { name, d, c, sync: () => c.sync() }; }
const norm = (d) => { const o = {}; SC.COLL.forEach((c) => { o[c] = (d[c] || []).map((r) => JSON.stringify(r, Object.keys(r).sort())).sort(); }); o.seq = d.seq; return JSON.stringify(o); };
const ids = (d, c) => d[c].map((r) => r.id).sort();

(async () => {
  const S = await start(); const ok = (m) => console.log('PASS ' + m);
  const A = dev('A', S.url), B = dev('B', S.url);

  // 1) إضافة وتعديل وحذف
  A.d.products.push({ id: 'p1', name: 'حليب', bc: '111', price: 80, qty: 5 });
  A.d.seq = 3; A.d.settings.currency = 'DA';
  await A.sync(); await B.sync();
  assert.strictEqual(B.d.products.length, 1); assert.strictEqual(B.d.products[0].name, 'حليب'); assert.strictEqual(B.d.seq, 3); assert.strictEqual(B.d.settings.currency, 'DA'); assert.strictEqual(B.d.shop, 'متجر'); ok('منتج وseq وإعدادات المتجر وصلت من A إلى B (الجهاز الجديد لا يطمس الإعدادات)');
  B.d.products[0].price = 95; await B.sync(); await A.sync();
  assert.strictEqual(A.d.products[0].price, 95); ok('تعديل السعر من B وصل إلى A');
  A.d.products.length = 0; await A.sync(); await B.sync();
  assert.strictEqual(B.d.products.length, 0); ok('الحذف انتقل (شاهد حذف)');
  // لا حلقات: دورة بلا تغيير لا تدفع شيئًا
  S.resetLog(); const r = await A.sync(); assert.strictEqual(r.pushed, 0); assert.ok(!S.log.some((l) => l.startsWith('PATCH'))); ok('دورة بلا تغيير لا تكتب شيئًا');

  // 2) تعارض: آخر تعديل يفوز (حتى لو عُدّل دون اتصال)
  A.d.products.push({ id: 'p2', name: 'خبز', bc: '222', price: 10 }); await A.sync(); await B.sync();
  A.d.products.find((p) => p.id === 'p2').price = 11; B.d.products.find((p) => p.id === 'p2').price = 12; // B أحدث
  await A.sync(); await B.sync(); await A.sync(); await B.sync();
  assert.strictEqual(A.d.products.find((p) => p.id === 'p2').price, 12); assert.strictEqual(B.d.products.find((p) => p.id === 'p2').price, 12); ok('آخر تعديل يفوز على الجهازين');

  // 3) نفس الباركود أُنشئ على الجهازين دون اتصال: يبقى معرّف واحد والفواتير تتبعه
  A.d.products.push({ id: 'zzz', name: 'سكر', bc: '333', price: 100 });
  B.d.products.push({ id: 'aaa', name: 'سكر', bc: '333', price: 101 });
  A.d.sales.push({ id: 's1', total: 100, lines: [{ pid: 'zzz', q: 1, p: 100 }] });
  B.d.sales.push({ id: 's2', total: 101, lines: [{ pid: 'aaa', q: 1, p: 101 }] });
  for (let i = 0; i < 3; i++) { await A.sync(); await B.sync(); }
  const sug = (d) => d.products.filter((p) => p.bc === '333');
  assert.strictEqual(sug(A.d).length, 1); assert.strictEqual(sug(B.d).length, 1); assert.strictEqual(sug(A.d)[0].id, 'aaa'); assert.strictEqual(sug(B.d)[0].id, 'aaa');
  assert.ok(A.d.sales.every((s) => s.lines[0].pid === 'aaa') && B.d.sales.every((s) => s.lines[0].pid === 'aaa')); assert.strictEqual(A.d.sales.length, 2);
  assert.strictEqual(norm(A.d), norm(B.d)); ok('تكرار الباركود: معرّف واحد (الأصغر) والفواتير أُعيد توجيهها على الجهازين');

  // 4) زبائن بنفس الاسم+الهاتف
  A.d.customers.push({ id: 'c9', name: 'علي', phone: '0555' }); B.d.customers.push({ id: 'c1', name: 'علي ', phone: '0555' });
  A.d.ledger.push({ id: 'l1', c: 'c9', amt: 50 });
  for (let i = 0; i < 3; i++) { await A.sync(); await B.sync(); }
  assert.strictEqual(A.d.customers.length, 1); assert.strictEqual(B.d.customers.length, 1); assert.strictEqual(B.d.ledger[0].c, 'c1'); assert.strictEqual(norm(A.d), norm(B.d)); ok('دمج الزبائن المكررين وتحديث الديون');

  // 5) جهاز جديد يسحب كل شيء بصفحات (أكثر من PAGE)
  for (let i = 0; i < 950; i++) A.d.products.push({ id: 'bulk' + i, name: 'م' + i, bc: 'x' + i, price: i });
  await A.sync(); const C = dev('C', S.url); await C.sync();
  assert.strictEqual(C.d.products.length, A.d.products.length); assert.strictEqual(norm(A.d), norm(C.d)); ok('جهاز جديد سحب ' + C.d.products.length + ' منتجًا عبر صفحات');

  // 6) مفاتيح بها رموز ممنوعة في Firebase
  A.d.products.push({ id: 'we.ird$id#[x]/y~z%', name: 'غريب', bc: 'w1' }); await A.sync(); await C.sync();
  assert.ok(C.d.products.some((p) => p.id === 'we.ird$id#[x]/y~z%')); ok('معرّفات بها . $ # [ ] / ~ % تعمل');

  // 7) أخطاء: قواعد غير منشورة / رفض / انقطاع
  S.setIndex(false); await assert.rejects(() => C.sync(), /rules-index/); S.setIndex(true);
  S.setDeny(true); await assert.rejects(() => C.sync(), /rules-denied/); S.setDeny(false);
  S.failNext(1); await assert.rejects(() => C.sync(), /HTTP 500/); await C.sync(); ok('أخطاء القواعد/الرفض/500 تُكتشف ثم يتعافى');

  // 8) دفعة جزئية: فشل في المنتصف ثم استئناف دون تكرار
  for (let i = 0; i < 250; i++) A.d.products.push({ id: 'pp' + i, name: 'n', bc: 'q' + i });
  S.resetLog(); let n = 0; const orig = A.c; // نسقط الدفعة الثانية
  const flaky = new CC.Firebase({ fb: S.url, code: CODE, db: () => A.d, dev: 'A', now: clock, http: async (r) => { if (r.method === 'PATCH' && ++n === 2) return { status: 500, text: '' }; return httpf(r); } });
  await assert.rejects(() => flaky.sync(), /HTTP 500/);
  const r2 = await orig.sync(); assert.ok(r2.pushed > 0 && r2.pushed < 250); await C.sync(); assert.strictEqual(norm(A.d), norm(C.d)); ok('فشل جزئي ثم استئناف يكمل الباقي فقط (' + r2.pushed + ')');

  // 9) اختبار عشوائي: عدة بذور، 3 أجهزة، عمليات عشوائية (إضافة/تعديل/حذف/فواتير/زبائن/seq/مزامنة)، ثم تقارب كامل
  for (const sd of [12345, 1, 2, 3, 4, 5, 6, 7]) {
    let seed = sd; const rnd = (n) => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed >> 4) % n; };
    const CODE2 = 'SEED' + sd + '-YYYY-XXXX-WWWW-VVVV-UUUU';
    const G = ['F1', 'F2', 'F3'].map((nm) => { const d = mkdb(); return { nm, d, c: new CC.Firebase({ fb: S.url, code: CODE2, db: () => d, http: httpf, dev: nm, now: clock }) }; });
    const BCS = ['b1', 'b2', 'b3', 'b4', 'b5', 'b6'];
    for (let step = 0; step < 500; step++) {
      const g = G[rnd(3)], op = rnd(11);
      if (op <= 1) { const bc = BCS[rnd(6)]; if (!g.d.products.some((p) => p.bc === bc)) g.d.products.push({ id: 'p' + g.nm + step, name: 'n' + step, bc, price: rnd(100) }); }
      else if (op === 2 && g.d.products.length) g.d.products[rnd(g.d.products.length)].price = rnd(1000);
      else if (op === 3 && g.d.products.length > 3) g.d.products.splice(rnd(g.d.products.length), 1);
      else if (op === 4 && g.d.products.length) g.d.sales.push({ id: 's' + g.nm + step, total: rnd(50), lines: [{ pid: g.d.products[rnd(g.d.products.length)].id, q: 1 }] });
      else if (op === 5) { const nm = 'cust' + rnd(4), ph = '0' + rnd(2); if (!g.d.customers.some((c) => c.name === nm && c.phone === ph)) { const cc = { id: 'c' + g.nm + step, name: nm, phone: ph }; g.d.customers.push(cc); g.d.ledger.push({ id: 'l' + g.nm + step, c: cc.id, amt: rnd(9) }); } }
      else if (op === 6) g.d.seq = Math.max(g.d.seq, rnd(500));
      else if (op === 7) g.d.settings.currency = 'C' + rnd(5);
      else await g.c.sync();
    }
    for (let round = 0; round < 7; round++) for (const g of G) await g.c.sync();
    const nn = G.map((g) => norm(g.d));
    if (nn[0] !== nn[1] || nn[1] !== nn[2]) { const a = JSON.parse(nn[0]), b = JSON.parse(nn[1]); for (const c of SC.COLL) { const x = new Set(a[c]), y = new Set(b[c]); console.log(c, 'only0', a[c].filter((z) => !y.has(z)).slice(0, 4), 'only1', b[c].filter((z) => !x.has(z)).slice(0, 4)); } throw new Error('no convergence seed ' + sd); }
    const bcs = G[0].d.products.map((p) => p.bc); assert.strictEqual(new Set(bcs).size, bcs.length, 'باركود مكرر بعد التقارب seed ' + sd);
    const cks = G[0].d.customers.map((c) => SC.nz(c.name) + '|' + SC.nz(c.phone)); assert.strictEqual(new Set(cks).size, cks.length, 'زبون مكرر seed ' + sd);
    const pids = new Set(G[0].d.products.map((p) => String(p.id))); const cids = new Set(G[0].d.customers.map((c) => String(c.id)));
    assert.ok(G[0].d.ledger.every((l) => cids.has(String(l.c))), 'دين يشير لزبون غير موجود seed ' + sd);
    assert.strictEqual(G[0].d.settings.currency, G[1].d.settings.currency); assert.strictEqual(G[0].d.seq, G[2].d.seq);
    ok('عشوائي seed=' + sd + ': تقارب كامل — ' + G[0].d.products.length + ' منتج، ' + G[0].d.customers.length + ' زبون، ' + G[0].d.sales.length + ' فاتورة');
  }

  S.close(); console.log('cloud tests OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
