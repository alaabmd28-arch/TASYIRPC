'use strict';
/* خادم وهمي يحاكي Firebase Realtime Database REST (+SSE) بما يكفي لاختبار المزامنة. */
const http = require('http');
function start(port = 0) {
  const store = {};            // sid -> { r:{key:node}, ping:{} }
  const sse = {};              // sid -> Set(res)
  let rulesIndex = true, deny = false, log = [], failNext = 0;
  const walkSV = (v) => { if (v && typeof v === 'object') { if (v['.sv'] === 'timestamp') return Date.now(); const o = Array.isArray(v) ? [] : {}; for (const k of Object.keys(v)) o[k] = walkSV(v[k]); return o; } return v; };
  const srv = http.createServer((q, r) => {
    const u = new URL(q.url, 'http://x');
    const h = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET,PUT,POST,PATCH,DELETE,OPTIONS', 'access-control-allow-headers': '*' };
    if (q.method === 'OPTIONS') { r.writeHead(204, h); return r.end(); }
    const m = /^\/s\/([^/]+)\/(r|ping)\.json$/.exec(u.pathname);
    log.push(q.method + ' ' + u.pathname + u.search);
    if (!m || !/^[a-f0-9]{40}$/.test(m[1]) || deny) { r.writeHead(401, h); return r.end('{"error":"Permission denied"}'); }
    if (failNext > 0) { failNext--; r.writeHead(500, h); return r.end('{"error":"boom"}'); }
    const [, sid, what] = m, S = store[sid] = store[sid] || { r: {}, ping: null };
    const body = [];
    q.on('data', (c) => body.push(c));
    q.on('end', () => {
      const send = (code, o) => { r.writeHead(code, { ...h, 'content-type': 'application/json' }); r.end(JSON.stringify(o)); };
      let b; try { b = body.length ? JSON.parse(Buffer.concat(body).toString()) : undefined; } catch (_) { return send(400, { error: 'bad json' }); }
      if (q.method === 'GET' && what === 'ping' && /event-stream/.test(q.headers.accept || '')) {
        r.writeHead(200, { ...h, 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive' });
        r.write('event: put\ndata: ' + JSON.stringify({ path: '/', data: S.ping }) + '\n\n');
        log.push('SSE open'); (sse[sid] = sse[sid] || new Set()).add(r); r.on('close', () => sse[sid].delete(r)); return;
      }
      if (what === 'r') {
        if (q.method === 'GET') {
          const ob = u.searchParams.get('orderBy');
          let ents = Object.entries(S.r);
          if (ob) {
            if (ob !== '"_s"') return send(400, { error: 'bad orderBy' });
            if (!rulesIndex) return send(400, { error: 'Index not defined, add ".indexOn": "_s", for path "/s/' + sid + '/r", to the rules' });
            const st = Number(u.searchParams.get('startAt') || -Infinity);
            ents = ents.filter(([, n]) => (n._s || 0) >= st).sort((a, c) => (a[1]._s - c[1]._s) || (a[0] < c[0] ? -1 : 1));
            const lim = Number(u.searchParams.get('limitToFirst') || 0); if (lim) ents = ents.slice(0, lim);
          }
          return send(200, ents.length ? Object.fromEntries(ents) : null);
        }
        if (q.method === 'PATCH') { const t = walkSV(b); for (const k of Object.keys(t)) { if (t[k] === null) delete S.r[k]; else S.r[k] = t[k]; } return send(200, t); }
      }
      if (what === 'ping' && q.method === 'PUT') {
        S.ping = walkSV(b);
        log.push('BROADCAST to ' + (sse[sid] ? sse[sid].size : 0));
        for (const res of sse[sid] || []) res.write('event: put\ndata: ' + JSON.stringify({ path: '/', data: S.ping }) + '\n\n');
        return send(200, S.ping);
      }
      if (what === 'ping' && q.method === 'GET') return send(200, S.ping);
      send(405, { error: 'method' });
    });
  });
  return new Promise((ok) => srv.listen(port, '127.0.0.1', () => ok({
    url: 'http://127.0.0.1:' + srv.address().port, store, log, close: () => { for (const s of Object.values(sse)) for (const r of s) r.end(); srv.closeAllConnections && srv.closeAllConnections(); srv.close(); },
    setIndex: (v) => { rulesIndex = v; }, setDeny: (v) => { deny = v; }, failNext: (n) => { failNext = n; }, resetLog: () => { log.length = 0; },
  })));
}
module.exports = { start };
