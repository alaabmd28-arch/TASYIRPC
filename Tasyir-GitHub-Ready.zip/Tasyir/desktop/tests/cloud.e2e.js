// متصفح حقيقي: جهازان (حاسوبان) على Firebase وهمي، مزامنة لحظية عبر SSE. التشغيل: NODE_PATH=... node tests/cloud.e2e.js
const { chromium } = require('playwright'), path = require('path'), fs = require('fs');
const { start } = require('./mockfb.js');
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const CODE = 'ABCD-EFGH-JKLM-NPQR-STUV-WXYZ';
const SEED = JSON.stringify({ lang: 'ar', shop: 'متجر التيسير', products: [
  { id: 'a1', arch: false, name: 'حليب نيدو 400غ', bc: '6111000000011', cost: 5000, price: 8000, stock: 10, min: 1, unit: 'u', fam: '', img: '' },
  { id: 'a2', arch: false, name: 'خبز', bc: '222', cost: 1000, price: 2000, stock: 50, min: 1, unit: 'u', fam: '', img: '' }], customers: [], sales: [], ledger: [], expenses: [], seq: 0 });
(async () => {
  const S = await start(), b = await chromium.launch(), errs = [];
  const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'root', 'index.html'), 'utf8').replace("connect-src 'self' https:", "connect-src 'self' https: http://127.0.0.1:*");
  async function mkdev(seed) {
    const c = await b.newContext({ viewport: { width: 1300, height: 820 } }), p = await c.newPage();
    p.on('pageerror', (e) => errs.push(e.message)); p.on('requestfailed', (r) => { if (!/favicon/.test(r.url())) console.log('REQFAIL', r.url()); });
    await p.exposeFunction('__http', async (r) => { try { const x = await fetch(r.url, { method: r.method, headers: r.headers, body: r.body }); return { status: x.status, text: await x.text() }; } catch (e) { return { status: 0, text: String(e) }; } });
    await p.addInitScript(([fb, seed]) => {
      window.__tasyirNative = { platform: 'win32', sendSync: (c) => (c === 'pin:info' ? { on: false, timeout: 0 } : true), send() {}, on() {}, invoke: async (c, a) => (c === 'http:fetch' ? window.__http(a) : c === 'sync:status' ? { enabled: false, hosts: [], port: 1, clients: {}, token: '' } : []) };
      localStorage.setItem('tasyir_cloud_cfg', JSON.stringify({ fb }));
      if (!localStorage.getItem('shopdb_v1') && seed) localStorage.setItem('shopdb_v1', seed);
    }, [S.url, seed]);
    await p.route('**/root/index.html*', (r) => r.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: html }));
    await p.goto('file://' + path.join(__dirname, '..', 'app', 'root', 'index.html')); await p.waitForTimeout(500); return p;
  }
  const A = await mkdev(SEED), B = await mkdev(null);
  // الصفحة الرئيسية تعرض شريط التفعيل قبل الربط
  ok(await A.evaluate(() => !!document.querySelector('.cbn')), 'شريط «فعّل المزامنة السحابية» يظهر في الرئيسية');
  await A.screenshot({ path: '/home/claude/shot-home-banner.png' });
  // كود قصير مرفوض
  await A.evaluate(() => TDcloud.open()); await A.waitForSelector('#clc');
  await A.fill('#clc', 'ABC'); await A.click('text=تفعيل المزامنة'); ok((await A.textContent('#cle')).includes('24'), 'كود غير مكتمل يُرفض برسالة');
  // قواعد غير منشورة: رسالة واضحة
  S.setIndex(false); await A.fill('#clc', CODE); await A.click('text=تفعيل المزامنة');
  await A.waitForSelector('text=قواعد Firebase غير منشورة', { timeout: 8000 }); ok(true, 'القواعد غير منشورة: رسالة إرشادية');
  S.setIndex(true); await A.evaluate(() => TDcloud.now()); await A.waitForSelector('text=متصل لحظيًا', { timeout: 8000 }); ok(true, 'A متصل لحظيًا (SSE)');
  await A.screenshot({ path: '/home/claude/shot-cloud-settings.png' });
  // B ينضم بنفس الكود ويستلم بيانات A
  await B.evaluate(() => TDcloud.open()); await B.waitForSelector('#clc'); await B.fill('#clc', 'abcd efgh jklm npqr stuv wxyz'); await B.click('text=تفعيل المزامنة');
  await B.waitForFunction(() => db.products.length === 2, null, { timeout: 8000 }); ok(true, 'B استلم منتجات A بعد إدخال الكود نفسه');
  // لحظي: تعديل سعر على A يصل B خلال ثوانٍ دون أي استدعاء يدوي (الدورة الاحتياطية 15ث)
  const t0 = Date.now(); await A.evaluate(() => { db.products.find((p) => p.bc === '222').price = 2500; save(); });
  await B.waitForFunction(() => db.products.find((p) => p.bc === '222').price === 2500, null, { timeout: 9000 }); const dt = Date.now() - t0;
  ok(dt < 9000, 'تعديل السعر على A وصل B لحظيًا خلال ' + dt + 'ms');
  // بيع على B ينتقل إلى A
  await B.evaluate(() => { const p = db.products.find((x) => x.bc === '6111000000011'); cart = [{ pid: p.id, name: p.name, price: p.price, cost: p.cost, qty: 2, tier: 'p1' }]; doSell(16000); });
  await A.waitForFunction(() => db.sales.length === 1 && db.products.find((p) => p.bc === '6111000000011').stock === 8, null, { timeout: 9000 }); ok(true, 'فاتورة B والمخزون وصلا إلى A لحظيًا');
  // حذف
  await A.evaluate(() => { db.products = db.products.filter((p) => p.bc !== '222'); save(); });
  await B.waitForFunction(() => !db.products.some((p) => p.bc === '222'), null, { timeout: 9000 }); ok(true, 'الحذف انتقل إلى B');
  // الشارة وصفحة الإعدادات
  await B.evaluate(() => { go('dash'); R(); }); await B.waitForTimeout(300);
  ok((await B.textContent('#cloudpill')).includes('لحظيًا'), 'شارة «متزامن لحظيًا» ظاهرة في الحاسوب');
  ok(await B.evaluate(() => !document.querySelector('.cbn')), 'شريط التفعيل يختفي بعد الربط');
  await B.screenshot({ path: '/home/claude/shot-home-cloud.png' });
  // بطاقة Drive بلا Client ID
  await B.evaluate(() => TDcloud.open()); await B.waitForTimeout(300);
  ok((await B.textContent('#m')).includes('Client ID'), 'بطاقة Drive تشرح المطلوب عند غياب Client ID');
  // إعادة تحميل: الاتصال يُستعاد تلقائيًا
  await B.reload(); await B.waitForTimeout(2500);
  ok(await B.evaluate(() => !!document.getElementById('cloudpill')), 'بعد إعادة التشغيل تبقى المزامنة مفعّلة');
  await A.evaluate(() => { db.products.find((p) => p.bc === '6111000000011').price = 8100; save(); });
  await B.waitForFunction(() => db.products.find((p) => p.bc === '6111000000011').price === 8100, null, { timeout: 9000 }); ok(true, 'تعمل اللحظية بعد إعادة التشغيل');
  ok(errs.length === 0, 'لا أخطاء JS ' + errs.slice(0, 3).join(' | '));
  await b.close(); S.close();
})().catch((e) => { console.error(e); process.exit(1); });
