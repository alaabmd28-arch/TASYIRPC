const { chromium } = require('playwright'), http = require('http'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..', 'app');
const srv = http.createServer((q, r) => { const f = path.join(root, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : f.endsWith('.css') ? 'text/css' : 'text/html' }); r.end(d); }); });
const names = ['حليب نيدو 400غ', 'خبز', 'سكر 1كغ', 'زيت المائدة 5ل', 'قهوة 250غ', 'ماء معدني 1.5ل', 'جبن', 'عصير', 'شاي', 'ملح'];
srv.listen(0, async () => {
  const b = await chromium.launch(), p = await b.newPage({ viewport: { width: 1440, height: 860 } }), errs = [];
  p.on('pageerror', (e) => errs.push(e.message));
  await p.addInitScript((names) => {
    window.__tasyirNative = { platform: 'win32', sendSync: (c) => (c === 'pin:info' ? { on: false, timeout: 0 } : true), send() {}, invoke: async () => [], on() {} };
    const products = names.map((n, i) => ({ id: 'p' + i, arch: false, name: n, bc: '61110000' + (1000 + i), cost: 5000 + i * 300, price: 8000 + i * 500, stock: 20 - i, min: 3, unit: 'u', fam: '', img: '' }));
    const day = new Date().toLocaleDateString('sv');
    const sales = [0, 1, 2].map((i) => ({ id: 's' + i, no: 'INV-0000' + (i + 1), d: new Date().toISOString(), day, lines: [{ pid: 'p' + i, name: names[i], qty: 2, price: 8000, cost: 5000, total: 16000 }], sub: 16000, disc: 0, total: 16000 + i * 4000, paid: 16000, debt: 0, cust: null }));
    localStorage.setItem('shopdb_v1', JSON.stringify({ lang: 'ar', shop: 'متجر التيسير', products, customers: [{ id: 'c1', name: 'علي', phone: '0550' }], sales, ledger: [], expenses: [], seq: 3 }));
  }, names);
  await p.goto(`http://localhost:${srv.address().port}/root/index.html`); await p.waitForTimeout(700);
  await p.screenshot({ path: '/home/claude/shot-home.png' });
  await p.evaluate(() => { go('pos'); [0, 1, 3].forEach((i) => addP('p' + i, 1)); addP('p1', 1); });
  await p.waitForTimeout(500); await p.screenshot({ path: '/home/claude/shot-pos.png' });
  await p.fill('#q', 'ز'); await p.waitForTimeout(300); await p.screenshot({ path: '/home/claude/shot-pos-search.png' });
  await p.setViewportSize({ width: 400, height: 800 }); await p.evaluate(() => go('dash')); await p.waitForTimeout(400); await p.screenshot({ path: '/home/claude/shot-narrow.png' });
  console.log('errors:', errs.join('|') || 'none'); await b.close(); srv.close();
});
