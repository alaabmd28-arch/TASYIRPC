'use strict';
const http = require('http');
function start() {
  const files = {}; let n = 0, pendingPolls = 2, tokens = 0, revoked = false; const log = [];
  const srv = http.createServer((q, r) => {
    const u = new URL(q.url, 'http://x'), chunks = [];
    q.on('data', (c) => chunks.push(c));
    q.on('end', () => {
      const body = Buffer.concat(chunks).toString(); log.push(q.method + ' ' + u.pathname);
      const send = (c, o, raw) => { r.writeHead(c, { 'content-type': raw ? 'text/plain' : 'application/json' }); r.end(raw ? o : JSON.stringify(o)); };
      if (u.pathname === '/device/code') { const f = new URLSearchParams(body); if (f.get('client_id') !== 'cid') return send(401, { error: 'invalid_client' }); return send(200, { device_code: 'DC', user_code: 'ABCD-EFGH', verification_url: 'https://www.google.com/device', expires_in: 600, interval: 1 }); }
      if (u.pathname === '/token') {
        const f = new URLSearchParams(body);
        if (f.get('client_secret') !== 'sec') return send(401, { error: 'invalid_client' });
        if (f.get('grant_type').includes('device_code')) { if (pendingPolls-- > 0) return send(428, { error: 'authorization_pending' }); return send(200, { access_token: 'AT' + (++tokens), refresh_token: 'RT', expires_in: 3600 }); }
        if (revoked) return send(400, { error: 'invalid_grant' });
        return send(200, { access_token: 'AT' + (++tokens), expires_in: 3600 });
      }
      const auth = q.headers.authorization || '';
      if (!/^Bearer AT\d+$/.test(auth)) return send(401, { error: 'unauth' });
      if (u.pathname === '/drive/v3/files' && q.method === 'GET') return send(200, { files: Object.values(files).map((f) => ({ id: f.id, name: f.name, modifiedTime: f.mt })) });
      let m = /^\/drive\/v3\/files\/(\w+)$/.exec(u.pathname);
      if (m && q.method === 'GET' && u.searchParams.get('alt') === 'media') return files[m[1]] ? send(200, files[m[1]].body, true) : send(404, {});
      if (u.pathname === '/upload/drive/v3/files' && q.method === 'POST') {
        const bd = /boundary=(.+)$/.exec(q.headers['content-type'])[1], parts = body.split('--' + bd).filter((x) => x.trim() && x.trim() !== '--');
        const meta = JSON.parse(parts[0].split('\r\n\r\n')[1].trim()), content = parts[1].split('\r\n\r\n').slice(1).join('\r\n\r\n').replace(/\r\n$/, '');
        const id = 'f' + (++n); files[id] = { id, name: meta.name, body: content, mt: new Date(Date.now() + n * 1000).toISOString() }; return send(200, { id });
      }
      if (m && q.method === 'DELETE') { if (!files[m[1]]) return send(404, {}); delete files[m[1]]; r.writeHead(204); return r.end(); }
      send(404, {});
    });
  });
  return new Promise((ok) => srv.listen(0, '127.0.0.1', () => { const b = 'http://127.0.0.1:' + srv.address().port; ok({ base: b, files, log, revoke: () => { revoked = true; }, close: () => { srv.closeAllConnections(); srv.close(); },
    g: { dev: b + '/device/code', tok: b + '/token', api: b + '/drive/v3', up: b + '/upload/drive/v3' } }); }));
}
module.exports = { start };
