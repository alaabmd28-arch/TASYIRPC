// أندرويد (ملفات assets الفعلية + جسر Android مُحاكى بما فيه httpFetch) ↔ حاسوب عبر Firebase وهمي. التشغيل: node tests/android.cloud.e2e.js [ASSETS]
const { chromium } = require('playwright'), path = require('path'), fs = require('fs'), http = require('http');
const { start } = require('./mockfb.js');
const ASSETS = process.argv[2] || '/home/claude/src/TasyirBMD/app/src/main/assets/htmlapp';
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const CODE = 'ABCDEFGHJKMNPQRSTVWXYZ12';
const SEED = JSON.stringify({ lang: 'ar', shop: 'متجر', products: [{ id: 'a1', arch: false, name: 'حليب', bc: '611', cost: 5000, price: 8000, stock: 10, min: 1, unit: 'u', fam: '', img: '' }], customers: [], sales: [], ledger: [], expenses: [], seq: 0 });
(async () => {
  const S = await start(), b = await chromium.launch(), errs = [], calls = [];
  const csp = (h) => h.replace("connect-src 'self' https:", "connect-src 'self' https: http://127.0.0.1:*");
  const pa = await (await b.newContext({ viewport: { width: 400, height: 800 } })).newPage(), pd = await (await b.newContext({ viewport: { width: 1300, height: 820 } })).newPage();
  [pa, pd].forEach((p) => p.on('pageerror', (e) => errs.push(e.message)));
  const nfetch = async (r) => { try { const x = await fetch(r.url, { method: r.method, headers: r.headers, body: r.body || undefined }); return { status: x.status, text: await x.text() }; } catch (e) { return { status: 0, text: String(e) }; } };
  await pa.exposeFunction('__nh', async (m, u, h, bd) => { calls.push(m); return nfetch({ url: u, method: m, headers: JSON.parse(h || '{}'), body: bd }); });
  await pd.exposeFunction('__http', nfetch);
  await pa.addInitScript(([fb, code, seed]) => {
    window.Android = { httpFetch: (id, m, u, h, bd) => { window.__nh(m, u, h, bd).then((r) => window.__httpRes(id, r.status, r.text)); }, licenseOwns: (c) => c.replace(/[^A-Za-z0-9]/g, '').toUpperCase() === code, scan() {}, stopScan() {}, pinInfo: () => '{"on":false,"timeout":60}', setSecure() {}, setLang() {}, btDevices: () => '{"list":[]}' };
    localStorage.setItem('tasyir_cloud_cfg', JSON.stringify({ fb })); localStorage.setItem('shopdb_v1', seed);
  }, [S.url, CODE, SEED]);
  await pd.addInitScript(([fb]) => {
    window.__tasyirNative = { platform: 'win32', sendSync: (c) => (c === 'pin:info' ? { on: false, timeout: 0 } : true), send() {}, on() {}, invoke: async (c, a) => (c === 'http:fetch' ? window.__http(a) : c === 'sync:status' ? { enabled: false, hosts: [], port: 1, clients: {}, token: '' } : []) };
    localStorage.setItem('tasyir_cloud_cfg', JSON.stringify({ fb }));
  }, [S.url]);
  const serve = (root) => new Promise((res) => { const s = http.createServer((q, r) => { const f = path.join(root, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } const ext = path.extname(f); r.writeHead(200, { 'content-type': { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css' }[ext] || 'application/octet-stream' }); r.end(ext === '.html' ? csp(d.toString()) : d); }); }); s.listen(0, '127.0.0.1', () => res(s)); });
  const sa = await serve(ASSETS), sd = await serve(path.join(__dirname, '..', 'app'));
  await pa.goto(`http://127.0.0.1:${sa.address().port}/root/index.html`); await pd.goto(`http://127.0.0.1:${sd.address().port}/root/index.html`); await pa.waitForTimeout(600);
  // أندرويد: صف المزامنة السحابية في الإعدادات
  await pa.evaluate(() => { tab = 'set'; sub = ''; R(); });
  ok(/المزامنة السحابية/.test(await pa.textContent('#m')), 'صف «المزامنة السحابية» ظاهر في إعدادات أندرويد');
  await pa.evaluate(() => { sub = 'cloud'; R(); }); await pa.waitForSelector('#clc');
  await pa.fill('#clc', 'WRONG123456789012345WXYZ'); await pa.click('text=تفعيل المزامنة'); ok(/ليس كود التفعيل/.test(await pa.textContent('#cle')), 'كود غير مفعَّل على الهاتف مرفوض');
  await pa.fill('#clc', 'abcd efgh jkmn pqrs tvwx yz12'); await pa.click('text=تفعيل المزامنة');
  await pa.waitForSelector('text=متصل لحظيًا', { timeout: 9000 }); ok(true, 'أندرويد متصل لحظيًا عبر الجسر الأصلي');
  ok(calls.includes('PATCH') && calls.includes('PUT') && calls.includes('GET'), 'الجسر الأصلي مرّ منه GET وPATCH وPUT (طرق: ' + [...new Set(calls)].join(',') + ')');
  await pa.screenshot({ path: '/home/claude/shot-android-cloud.png' });
  // الحاسوب ينضم بنفس الكود
  await pd.evaluate(() => TDcloud.open()); await pd.waitForSelector('#clc'); await pd.fill('#clc', CODE); await pd.click('text=تفعيل المزامنة');
  await pd.waitForFunction(() => db.products.length === 1 && db.products[0].price === 8000, null, { timeout: 9000 }); ok(true, 'الحاسوب استلم منتجات الهاتف');
  const t0 = Date.now(); await pa.evaluate(() => { db.products[0].price = 9000; save(); });
  await pd.waitForFunction(() => db.products[0].price === 9000, null, { timeout: 9000 }); ok(true, 'سعر الهاتف وصل الحاسوب لحظيًا (' + (Date.now() - t0) + 'ms)');
  await pd.evaluate(() => { db.products.push({ id: 'z9', arch: false, name: 'جديد', bc: '999', cost: 1, price: 2, stock: 3, min: 0, unit: 'u', fam: '', img: '' }); save(); });
  await pa.waitForFunction(() => db.products.some((p) => p.bc === '999'), null, { timeout: 9000 }); ok(true, 'منتج جديد من الحاسوب وصل الهاتف لحظيًا');
  await pa.evaluate(() => { db.products = db.products.filter((p) => p.bc !== '999'); save(); });
  await pd.waitForFunction(() => !db.products.some((p) => p.bc === '999'), null, { timeout: 9000 }); ok(true, 'الحذف من الهاتف وصل الحاسوب');
  ok(await pa.evaluate(() => !document.getElementById('cloudpill')), 'لا شارة عائمة على أندرويد');
  ok(errs.length === 0, 'لا أخطاء JS ' + errs.slice(0, 3).join(' | '));
  await b.close(); S.close(); sa.close(); sd.close();
})().catch((e) => { console.error(e); process.exit(1); });
