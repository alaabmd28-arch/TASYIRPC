/* Tasyir — واجهة المزامنة السحابية (حاسوب + هاتف):
   Firebase لحظي (SSE + دورة احتياطية) + Google Drive (لقطات كاملة بطيئة). المنطق في cloud-core.js. */
(function () {
  'use strict';
  var CC = window.CloudCore, SC = window.SyncCore;
  if (!CC || !SC || typeof VIEWS === 'undefined') return;
  var N = window.__tasyirNative, AND = window.Android;
  var $i = function (i) { return document.getElementById(i); };
  var jp = function (s, d) { try { return JSON.parse(s); } catch (e) { return d; } };
  var Lx = function (a, f, e) { return L(a, f, e); };
  var lsGet = function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } };
  var lsSet = function (k, v) { try { localStorage.setItem(k, v); } catch (e) { /* لا شيء */ } };
  var busyUI = function () { var o = $i('ov'); return (o && o.innerHTML.trim()) || (document.activeElement && /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)); };
  var refresh = function () { try { if (!busyUI()) R(); } catch (e) { /* لا شيء */ } };
  var repaint = function () { try { if (tab === 'set' && sub === 'cloud' && !busyUI()) R(); } catch (e) { /* لا شيء */ } pill(); };

  /* ---------------- الإعدادات والهوية ---------------- */
  var DEF = window.TASYIR_CLOUD || {};
  function conf() { var o = jp(lsGet('tasyir_cloud_cfg'), {}) || {}; return { fb: o.fb || DEF.fb || '', gid: o.gid || DEF.gClientId || '', gsec: o.gsec || DEF.gClientSecret || '' }; }
  function dev() { var d = lsGet('tasyir_dev'); if (!d || d.length < 8) { d = (Date.now().toString(36) + Math.random().toString(36).slice(2, 10)).slice(0, 16); lsSet('tasyir_dev', d); } return d; }

  /* ---------------- النقل HTTP ---------------- */
  var pend = {}, hseq = 0;
  window.__httpRes = function (id, status, text) { var p = pend[id]; if (!p) return; delete pend[id]; p({ status: status, text: text }); };
  function http(r) {
    if (N) return N.invoke('http:fetch', r).catch(function (e) { return { status: 0, text: String(e && e.message || e) }; });
    if (AND && typeof AND.httpFetch === 'function') {
      return new Promise(function (ok) {
        var id = ++hseq, t = setTimeout(function () { delete pend[id]; ok({ status: 0, text: 'timeout' }); }, 80000);
        pend[id] = function (x) { clearTimeout(t); ok(x); };
        try { AND.httpFetch(id, r.method || 'GET', r.url, JSON.stringify(r.headers || {}), r.body == null ? '' : String(r.body)); } catch (e) { delete pend[id]; clearTimeout(t); ok({ status: 0, text: String(e) }); }
      });
    }
    return fetch(r.url, { method: r.method || 'GET', headers: r.headers, body: r.body }).then(function (x) { return x.text().then(function (t) { return { status: x.status, text: t }; }); }).catch(function (e) { return { status: 0, text: String(e) }; });
  }

  /* ---------------- الحالة ---------------- */
  var CK = 'tasyir_cloud', cs = jp(lsGet(CK), null);
  var S = { ts: 0, err: '', run: 0, live: 0, again: 0, pulled: 0, pushed: 0 };
  var D = { ts: 0, err: '', run: 0, merged: 0, auth: null, authMsg: '', authErr: '' };
  var fbs = null, drv = null, es = null, evT = 0, saveT = 0;
  var MSG = function (e) {
    e = String(e || '');
    return /rules-index/.test(e) ? Lx('قواعد Firebase غير منشورة بعد: افتح Firebase ← Realtime Database ← Rules والصق ملف firebase-rules.json ثم Publish.', 'Règles Firebase non publiées : collez firebase-rules.json dans Rules puis Publish.', 'Firebase rules not published: paste firebase-rules.json in Rules, then Publish.')
      : /rules-denied/.test(e) ? Lx('Firebase رفض الوصول: تأكد من نشر القواعد (firebase-rules.json).', 'Firebase a refusé l\'accès : publiez les règles.', 'Firebase denied access: publish the rules.')
        : /network|timeout|Failed to fetch/i.test(e) ? Lx('لا يوجد اتصال بالإنترنت', 'Pas de connexion Internet', 'No Internet connection')
          : /no-client/.test(e) ? Lx('أدخل Client ID وSecret لـ Google أولًا (متقدّم)', 'Saisissez le Client ID/Secret Google (avancé)', 'Enter the Google Client ID/Secret first (advanced)')
            : /revoked/.test(e) ? Lx('أُلغي إذن Google: اربط الحساب من جديد', 'Autorisation Google révoquée : reliez le compte', 'Google access revoked: link the account again')
              : /expired/.test(e) ? Lx('انتهت مهلة الرمز، أعد المحاولة', 'Code expiré, réessayez', 'Code expired, try again')
                : /access_denied/.test(e) ? Lx('رُفض الإذن من حساب Google', 'Autorisation refusée', 'Permission denied')
                  : e;
  };
  var ago = function (t) { if (!t) return '…'; var s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 60 ? Lx('قبل ' + s + ' ث', 'il y a ' + s + ' s', s + 's ago') : s < 3600 ? Lx('قبل ' + Math.round(s / 60) + ' د', 'il y a ' + Math.round(s / 60) + ' min', Math.round(s / 60) + 'm ago') : new Date(t).toLocaleTimeString(LC()); };

  function mk() {
    fbs = cs ? new CC.Firebase({ fb: conf().fb, sid: cs.sid, db: function () { return db; }, http: http, dev: dev() }) : null;
    drv = cs ? new CC.Drive({
      sid: cs.sid, db: function () { return db; }, http: http, dev: dev(), cfg: { clientId: conf().gid, clientSecret: conf().gsec },
      store: { get: function () { return jp(lsGet('tasyir_gd'), {}) || {}; }, set: function (x) { lsSet('tasyir_gd', JSON.stringify(x)); } }
    }) : null;
  }

  /* ---------------- Firebase: دورة المزامنة ---------------- */
  async function run(manual) {
    if (!cs || !fbs) return;
    if (S.run) { S.again = 1; return; }
    S.run = 1;
    try {
      var r = await fbs.sync();
      S.err = ''; S.ts = Date.now(); S.pulled = r.pulled || 0; S.pushed = r.pushed || 0;
      if (r.pulled || r.pushed) saveNow();
      if (r.pulled) refresh();
      if (manual) toast('[ok] ' + Lx('تمت المزامنة', 'Synchronisé', 'Synced'));
    } catch (e) { S.err = MSG(e && e.message); if (manual) toast('[warn] ' + S.err); }
    finally { S.run = 0; if (S.again) { S.again = 0; setTimeout(run, 300); } repaint(); }
  }
  function listen() {
    try { if (es) es.close(); } catch (e) { /* لا شيء */ } es = null; S.live = 0;
    if (!cs || !fbs || typeof window.EventSource !== 'function') return;
    try {
      es = new EventSource(fbs.pingUrl());
      es.onopen = function () { S.live = 1; repaint(); };
      es.onerror = function () { S.live = 0; repaint(); };
      es.addEventListener('put', function (e) {
        S.live = 1; var m = jp(e.data, {}) || {}, d = m.data;
        if (d && d.by === dev()) return;
        clearTimeout(evT); evT = setTimeout(run, 350);
      });
      es.addEventListener('patch', function () { clearTimeout(evT); evT = setTimeout(run, 350); });
      es.addEventListener('auth_revoked', function () { S.live = 0; });
    } catch (e) { S.live = 0; }
  }

  /* ---------------- Google Drive ---------------- */
  async function driveRun(manual) {
    if (!cs || !drv || !drv.connected() || D.run) return;
    D.run = 1;
    try {
      var r = await drv.sync(manual ? { force: true } : { gap: 10 * 60 * 1000 });
      D.err = ''; D.ts = Date.now(); D.merged = r.merged || 0;
      if (r.merged) { saveNow(); refresh(); }
      if (manual) toast('[ok] ' + Lx('تمت مزامنة Google Drive', 'Google Drive synchronisé', 'Google Drive synced'));
    } catch (e) { D.err = MSG(e && e.message); if (manual) toast('[warn] ' + D.err); }
    finally { D.run = 0; repaint(); }
  }
  async function authPoll() {
    var a = D.auth; if (!a || !drv) return;
    try {
      var r = await drv.poll(a);
      if (r === 'ok') { D.auth = null; D.authErr = ''; repaint(); driveRun(true); return; }
      setTimeout(authPoll, a.interval * 1000);
    } catch (e) { D.auth = null; D.authErr = MSG(e && e.message); repaint(); }
  }

  /* ---------------- الربط والإيقاف ---------------- */
  var API = window.TDcloud = {
    connect: async function () {
      var code = ($i('clc') || {}).value || '', err = function (m) { var e = $i('cle'); if (e) e.textContent = m; };
      if (SC.normCode(code).length !== 24) return err(Lx('كود التفعيل 24 خانة', 'Le code fait 24 caractères', 'Activation code is 24 characters'));
      if (AND && typeof AND.licenseOwns === 'function' && !AND.licenseOwns(code)) return err(Lx('هذا ليس كود التفعيل المفعَّل على هذا الهاتف', 'Ce n\'est pas le code activé sur ce téléphone', 'This is not the activation code activated on this phone'));
      cs = { sid: CC.shopId(code), on: 1 }; lsSet(CK, JSON.stringify(cs)); mk(); listen();
      S.err = ''; repaint();
      await run(true); startTimers(); repaint();
    },
    stop: function () {
      if (!confirm(t('cf'))) return;
      try { if (es) es.close(); } catch (e) { /* لا شيء */ } es = null; cs = null; fbs = null; drv = null; S.live = 0;
      try { localStorage.removeItem(CK); localStorage.removeItem('tasyir_gd'); } catch (e) { /* لا شيء */ }
      try { db._cloud = null; } catch (e) { /* لا شيء */ } D.auth = null; repaint();
    },
    now: function () { run(true); },
    gAuth: async function () {
      D.authErr = ''; D.auth = null;
      try { D.auth = await drv.begin(); D.authMsg = ''; repaint(); setTimeout(authPoll, D.auth.interval * 1000); }
      catch (e) { D.authErr = MSG(e && e.message); repaint(); }
    },
    gOff: function () { if (!confirm(t('cf'))) return; if (drv) drv.disconnect(); D.auth = null; repaint(); },
    gNow: function () { driveRun(true); },
    gCancel: function () { D.auth = null; repaint(); },
    cfgSave: function () {
      lsSet('tasyir_cloud_cfg', JSON.stringify({ fb: ($i('clfb') || {}).value.trim(), gid: ($i('clgi') || {}).value.trim(), gsec: ($i('clgs') || {}).value.trim() }));
      var wasOn = !!cs; if (wasOn) { mk(); listen(); } toast('[ok] ' + Lx('تم الحفظ', 'Enregistré', 'Saved')); repaint(); if (wasOn) run(true);
    },
    phone: function () { sub = 'phone'; R(); },
    open: function () { go('set'); sub = 'cloud'; R(); },
    skip: function () { lsSet('tasyir_cloud_skip', '1'); R(); },
    banner: function () {
      if (cs || lsGet('tasyir_cloud_skip')) return '';
      return '<div class="cbn"><span class="cbi">' + ic('cloud') + '</span><div class="cbt"><b>' + Lx('فعّل المزامنة السحابية', 'Activez la synchronisation cloud', 'Enable cloud sync') + '</b><div class="k">' +
        Lx('اربط الحاسوب والهاتف بكود التفعيل ليتزامن كل شيء لحظيًا.', 'Reliez PC et téléphone avec le code d\'activation : tout se synchronise en direct.', 'Link PC and phone with the activation code: everything syncs live.') + '</div></div>' +
        '<button class="b" onclick="TDcloud.open()">' + Lx('تفعيل', 'Activer', 'Enable') + '</button><button class="b s" onclick="TDcloud.skip()">' + Lx('لاحقًا', 'Plus tard', 'Later') + '</button></div>';
    }
  };

  /* ---------------- شارة الحالة (الحاسوب) ---------------- */
  function pill() {
    var p = $i('cloudpill'), on = !!cs;
    if (!(N && on)) { if (p) p.remove(); return; }
    if (!p) { p = document.createElement('button'); p.id = 'cloudpill'; p.onclick = API.open; document.body.appendChild(p); }
    var col = S.err ? '#dc2626' : S.live ? '#16a34a' : '#d97706';
    p.innerHTML = '<i style="background:' + col + '"></i>' + (S.err ? Lx('تعذّرت المزامنة', 'Échec synchro', 'Sync failed') : S.live ? Lx('متزامن لحظيًا', 'Synchro en direct', 'Live sync') : Lx('متزامن', 'Synchronisé', 'Synced'));
    p.title = S.err || (Lx('آخر مزامنة: ', 'Dernière synchro : ', 'Last sync: ') + ago(S.ts));
  }

  /* ---------------- صفحة الإعدادات ---------------- */
  var TT = function () { return Lx('المزامنة السحابية', 'Synchronisation cloud', 'Cloud sync'); };
  var _hdr = hdr; hdr = function () { _hdr(); if (sub === 'cloud') { var e = $i('ttl'); if (e) e.textContent = TT(); } };
  var dot = function (c) { return '<span style="color:' + c + '">●</span> '; };
  function fbCard() {
    if (!cs) {
      return '<div class="card"><b>' + ic('cloud') + ' ' + Lx('ربط الحاسوب والهاتف (Firebase)', 'Lier PC et téléphone (Firebase)', 'Link PC and phone (Firebase)') + '</b>' +
        '<div class="k" style="margin:6px 0">' + Lx('أدخل كود التفعيل نفسه على كل جهاز: يتزامن كل شيء (الأسعار، السلع، المبيعات، الزبائن…) لحظيًا، ويحتفظ كل جهاز بنسخته إن انقطع الإنترنت.', 'Saisissez le même code d\'activation sur chaque appareil : prix, produits, ventes, clients… se synchronisent en direct, même après une coupure.', 'Enter the same activation code on every device: prices, products, sales, customers… sync live, and each device keeps working offline.') + '</div>' +
        '<input id="clc" autocomplete="off" style="direction:ltr" placeholder="XXXX-XXXX-XXXX-XXXX-XXXX-XXXX"><div class="red" id="cle" style="min-height:20px;margin-top:6px"></div>' +
        '<button class="b" style="width:100%;margin-top:4px" onclick="TDcloud.connect()">' + ic('check') + ' ' + Lx('تفعيل المزامنة', 'Activer la synchronisation', 'Enable sync') + '</button></div>';
    }
    var c = S.err ? '#dc2626' : S.live ? '#16a34a' : '#d97706', st = S.err ? S.err : S.live ? Lx('متصل لحظيًا', 'Connecté en direct', 'Live connected') : Lx('متصل (تحديث دوري)', 'Connecté (périodique)', 'Connected (periodic)');
    return '<div class="card"><b>' + dot(c) + Lx('المزامنة السحابية مفعّلة', 'Synchronisation cloud active', 'Cloud sync enabled') + '</b>' +
      '<div class="k" style="margin:6px 0">' + (S.err ? '<span class="red">' + esc(st) + '</span>' : esc(st)) + '</div>' +
      '<div class="k">' + Lx('آخر مزامنة: ', 'Dernière synchro : ', 'Last sync: ') + ago(S.ts) + (S.run ? ' · …' : '') + '</div>' +
      '<div class="bar" style="margin-top:8px"><button class="b" onclick="TDcloud.now()">' + ic('refresh') + ' ' + Lx('زامن الآن', 'Synchroniser', 'Sync now') + '</button><button class="b r" onclick="TDcloud.stop()">' + Lx('إيقاف', 'Arrêter', 'Stop') + '</button></div></div>';
  }
  function driveCard() {
    if (!cs) return '';
    var h = '<div class="card"><b>' + ic('save') + ' ' + Lx('Google Drive (نسخة كاملة ومزامنة بطيئة)', 'Google Drive (copie complète, synchro lente)', 'Google Drive (full copy, slow sync)') + '</b>';
    var cf = conf();
    if (!cf.gid || !cf.gsec) return h + '<div class="k" style="margin-top:6px">' + Lx('غير مفعّل: يحتاج Client ID وSecret من Google Cloud (انظر الدليل). أدخلهما في «متقدّم» أدناه.', 'Non activé : Client ID/Secret Google Cloud requis (voir guide). Saisissez-les dans « Avancé ».', 'Not enabled: needs a Google Cloud Client ID/Secret (see guide). Enter them in “Advanced” below.') + '</div></div>';
    if (drv && drv.connected()) {
      return h + '<div class="k" style="margin:6px 0">' + dot(D.err ? '#dc2626' : '#16a34a') + (D.err ? '<span class="red">' + esc(D.err) + '</span>' : Lx('الحساب مربوط — تُرفع نسخة كاملة وتُدمج نسخ الأجهزة الأخرى تلقائيًا كل 5 دقائق.', 'Compte lié — copie complète envoyée et copies des autres appareils fusionnées toutes les 5 min.', 'Account linked — full copy uploaded and other devices\' copies merged every 5 min.')) + '</div>' +
        '<div class="k">' + Lx('آخر مزامنة: ', 'Dernière synchro : ', 'Last sync: ') + ago(D.ts) + (D.run ? ' · …' : '') + '</div>' +
        '<div class="bar" style="margin-top:8px"><button class="b" onclick="TDcloud.gNow()">' + ic('refresh') + ' ' + Lx('زامن الآن', 'Synchroniser', 'Sync now') + '</button><button class="b r" onclick="TDcloud.gOff()">' + Lx('فصل الحساب', 'Délier', 'Unlink') + '</button></div></div>';
    }
    if (D.auth) {
      return h + '<div class="k" style="margin:6px 0">' + Lx('1) افتح الرابط أدناه  2) أدخل الرمز  3) اختر حساب Google ووافق. ستكتمل العملية هنا تلقائيًا.', '1) Ouvrez le lien  2) Saisissez le code  3) Choisissez le compte Google et autorisez.', '1) Open the link  2) Enter the code  3) Pick the Google account and allow.') + '</div>' +
        '<div style="text-align:center;font-size:28px;font-weight:800;letter-spacing:4px;direction:ltr;margin:8px 0">' + esc(D.auth.user_code) + '</div>' +
        '<div style="text-align:center;direction:ltr;margin-bottom:8px"><a href="' + esc(D.auth.url) + '" style="color:var(--pr);font-weight:700">' + esc(D.auth.url) + '</a></div>' +
        '<div class="k" style="text-align:center">' + Lx('بانتظار الموافقة…', 'En attente d\'autorisation…', 'Waiting for approval…') + '</div>' +
        '<div class="bar" style="margin-top:8px"><button class="b s" onclick="TDcloud.gCancel()">' + t('cancel') + '</button></div></div>';
    }
    return h + '<div class="k" style="margin:6px 0">' + Lx('اربط حساب Google الخاص بالمتجر (نفسه على الحاسوب والهاتف). تُحفظ البيانات في مساحة التطبيق المخفية داخل Drive، ولا تظهر ملفاتك الأخرى للتطبيق.', 'Liez le compte Google de la boutique (le même sur PC et téléphone). Les données vont dans l\'espace caché de l\'app sur Drive ; vos autres fichiers restent inaccessibles.', 'Link the shop\'s Google account (same on PC and phone). Data goes to the app\'s hidden Drive space; your other files stay inaccessible.') + '</div>' +
      (D.authErr ? '<div class="red" style="margin-bottom:6px">' + esc(D.authErr) + '</div>' : '') +
      '<button class="b" style="width:100%" onclick="TDcloud.gAuth()">' + ic('key') + ' ' + Lx('ربط حساب Google', 'Lier un compte Google', 'Link Google account') + '</button></div>';
  }
  function advCard() {
    var c = conf();
    return '<details class="card"><summary><b>' + Lx('متقدّم', 'Avancé', 'Advanced') + '</b></summary>' +
      '<label class="k">Firebase Database URL</label><input id="clfb" style="direction:ltr" value="' + esc(c.fb) + '">' +
      '<label class="k">Google Client ID</label><input id="clgi" style="direction:ltr" value="' + esc(c.gid) + '">' +
      '<label class="k">Google Client Secret</label><input id="clgs" style="direction:ltr" value="' + esc(c.gsec) + '">' +
      '<button class="b s" style="width:100%;margin-top:8px" onclick="TDcloud.cfgSave()">' + t('save') + '</button></details>';
  }
  SUBV.cloud = function () {
    return fbCard() + driveCard() + (N ? '<div class="card"><div class="sr" onclick="TDcloud.phone()"><span class="ic">' + ic('scan') + '</span><div class="st"><b>' + Lx('ربط الهاتف بالـQR (شبكة محلية)', 'Lier le téléphone par QR (réseau local)', 'Link phone by QR (local network)') + '</b><div class="k">' + Lx('بديل بلا إنترنت: على نفس الواي فاي', 'Sans Internet : même Wi-Fi', 'No Internet needed: same Wi-Fi') + '</div></div><span class="ar">' + ic('next') + '</span></div></div>' : '') + advCard();
  };
  var _vs = VIEWS.set; VIEWS.set = function () {
    var h = _vs(); if (sub) return h;
    var on = cs ? dot(S.err ? '#dc2626' : S.live ? '#16a34a' : '#d97706') : '';
    return '<div class="sg">' + SR(ic('cloud'), TT(), Lx('Firebase لحظي + Google Drive', 'Firebase en direct + Google Drive', 'Live Firebase + Google Drive'), on, "sub='cloud';R()") + '</div>' + h;
  };

  /* ---------------- التشغيل ---------------- */
  var timers = 0;
  function startTimers() {
    if (timers) return; timers = 1;
    setInterval(function () { if (cs && !document.hidden && (!S.live || Date.now() - S.ts > 60000)) run(); pill(); }, 15000);
    setInterval(function () { if (cs && !document.hidden) driveRun(); }, 5 * 60 * 1000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden && cs) { run(); if (!es || es.readyState === 2) listen(); } });
    addEventListener('online', function () { if (cs) { listen(); run(); } });
    var prev = window.onSaved;
    window.onSaved = function () { try { prev && prev(); } catch (e) { /* لا شيء */ } if (!cs || S.run) return; clearTimeout(saveT); saveT = setTimeout(run, 2500); };
  }
  if (cs) { mk(); listen(); startTimers(); setTimeout(run, 1200); setTimeout(function () { driveRun(); }, 8000); }
  pill();
})();
