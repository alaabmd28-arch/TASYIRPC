/* Tasyir — المزامنة السحابية (حاسوب + هاتف). منطق خالص لا يعتمد على DOM ولا Electron:
   (1) Firebase Realtime Database عبر REST: مزامنة لحظية (ping) + سجل تغييرات مرتّب بوقت الخادم (_s).
   (2) Google Drive (appDataFolder): لقطة كاملة لكل جهاز تُدمج في الأجهزة الأخرى (مزامنة بطيئة + نسخ احتياطي).
   كلاهما يستعمل SyncCore.peerApply، فالدمج حتمي ومتطابق على كل الأجهزة (آخر تعديل يفوز، شواهد حذف، حسم تكرار الباركود). */
(function (root, f) { if (typeof module === 'object' && module.exports) module.exports = f(require('./sync-core.js')); else root.CloudCore = f(root.SyncCore); })(this, function (SC) {
  'use strict';
  var COLL = SC.COLL, SV = { '.sv': 'timestamp' };
  var PAGE = 400, CHUNK = 100, OVERLAP = 5000;
  var sk = function (x) { return String(x); };
  var jp = function (s, d) { try { return JSON.parse(s); } catch (e) { return d; } };

  /* معرّف المتجر في السحابة: مشتق من كود التفعيل (لا يمكن تخمينه، ولا يكشف الكود) */
  var shopId = function (code) { return SC.sha256('tasyir-cloud|' + SC.normCode(code)).slice(0, 40); };
  /* مفاتيح Firebase لا تقبل . $ # [ ] / ولا ~ (فاصلنا) */
  var ek = function (s) { return sk(s).replace(/[%~.$#\[\]\/\u0000-\u001f\u007f]/g, function (c) { return '%' + ('0' + c.charCodeAt(0).toString(16)).slice(-2).toUpperCase(); }); };
  var dk = function (s) { return s.replace(/%([0-9A-F]{2})/g, function (_, h) { return String.fromCharCode(parseInt(h, 16)); }); };

  function fresh(dev, sid) { return { dev: dev, sid: sid, cur: 0, rh: {}, rt: {}, rs: 0, rq: 0 }; }

  /* ============================== Firebase ============================== */
  function Firebase(o) {
    var self = this, base = String(o.fb || '').replace(/\/+$/, '');
    self.sid = o.sid || shopId(o.code);
    var now = o.now || Date.now, http = o.http, busy = 0;
    var db = function () { return o.db(); };
    var cl = function () { var d = db(), c = d._cloud; if (!c || c.dev !== o.dev || c.sid !== self.sid) c = d._cloud = fresh(o.dev, self.sid); return c; };
    var url = function (p, q) { return base + '/s/' + self.sid + '/' + p + '.json' + (q ? '?' + q : ''); };
    var J = function (m, u, body) { return http({ method: m, url: u, headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) }); };
    var fail = function (r, what) {
      var t = String(r.text || '');
      if (r.status === 400 && /index/i.test(t)) return new Error('rules-index');
      if (r.status === 401 || r.status === 403) return new Error('rules-denied');
      if (!r.status) return new Error('network');
      return new Error(what + ' HTTP ' + r.status);
    };
    self.cloudState = cl;

    function decode(nodes) {
      var ch = { c: {}, tomb: {}, set: null, seq: 0 }, maxS = 0;
      Object.keys(nodes).forEach(function (key) {
        var n = nodes[key]; if (!n || typeof n !== 'object') return;
        maxS = Math.max(maxS, +n._s || 0);
        if (key === 'set') { var v = jp(n.j, null); if (v) ch.set = { u: +n._u || 0, v: v }; return; }
        if (key === 'seq') { ch.seq = +n.n || 0; return; }
        var i = key.indexOf('~'); if (i < 1) return;
        var c = key.slice(0, i), id = dk(key.slice(i + 1)); if (COLL.indexOf(c) < 0) return;
        if (n.x) { (ch.tomb[c] = ch.tomb[c] || {})[id] = +n._u || 0; return; }
        var r = jp(n.j, null); if (!r || typeof r !== 'object') return;
        r._u = +n._u || 0; if (r.id === undefined) r.id = id;
        (ch.c[c] = ch.c[c] || []).push(r);
      });
      return { ch: ch, maxS: maxS };
    }

    /* يعلّم ما تطابقت نسخته المحلية مع السحابة فلا يُدفع من جديد */
    function markKnown(ch) {
      var d = db(), m = d._sync || {}, c0 = cl();
      Object.keys(ch.c).forEach(function (c) {
        var idx = {}; (d[c] || []).forEach(function (r) { idx[sk(r.id)] = r; });
        var rh = (c0.rh[c] = c0.rh[c] || {});
        ch.c[c].forEach(function (r) { var l = idx[sk(r.id)]; if (l && l._u === r._u) rh[sk(r.id)] = r._u; });
      });
      Object.keys(ch.tomb).forEach(function (c) {
        var rt = (c0.rt[c] = c0.rt[c] || {});
        Object.keys(ch.tomb[c]).forEach(function (id) { if (((m.tomb || {})[c] || {})[id] === ch.tomb[c][id]) rt[id] = ch.tomb[c][id]; });
      });
      if (ch.set && m.setU === ch.set.u) c0.rs = ch.set.u;
      if (ch.seq > c0.rq) c0.rq = ch.seq;
    }

    /* ---------- سحب التغييرات الجديدة ---------- */
    self.pull = async function () {
      var c0 = cl(), applied = 0, pages = 0, from = Math.max(0, c0.cur - OVERLAP), top = c0.cur;
      for (;;) {
        var r = await http({ method: 'GET', url: url('r', 'orderBy=%22_s%22&startAt=' + from + '&limitToFirst=' + PAGE) });
        if (r.status < 200 || r.status >= 300) throw fail(r, 'pull');
        var nodes = jp(r.text, null) || {}, keys = Object.keys(nodes);
        if (!keys.length) break;
        var dec = decode(nodes);
        // أول اتصال لهذا الجهاز: إعدادات المتجر الموجودة في السحابة تفوز على الإعدادات الافتراضية للجهاز الجديد
        if (!c0.rs && dec.ch.set && db()._sync) db()._sync.setU = 0;
        var res = SC.peerApply(db(), dec.ch, now());
        applied += Object.keys(res.applied).length;
        markKnown(dec.ch);
        top = Math.max(top, dec.maxS);
        if (keys.length < PAGE) break;
        // صفحة ممتلئة: تابع من آخر _s (شاملًا) ؛ إن لم يتقدم المؤشر نقفز واحدًا لتفادي الحلقة
        from = dec.maxS > from ? dec.maxS : from + 1;
        if (++pages > 2000) break;
      }
      c0.cur = top;
      return applied;
    };

    /* ---------- دفع التغييرات المحلية ---------- */
    self.push = async function () {
      var d = db(), c0 = cl(), ch = SC.peerCollect(d, c0);
      if (SC.peerEmpty(ch)) return 0;
      var items = [];
      COLL.forEach(function (c) {
        (ch.c[c] || []).forEach(function (r) { items.push({ k: c + '~' + ek(r.id), v: { _u: r._u || 0, _s: SV, j: JSON.stringify(r) }, ok: function () { (c0.rh[c] = c0.rh[c] || {})[sk(r.id)] = r._u; } }); });
        Object.keys(ch.tomb[c] || {}).forEach(function (id) { var ts = ch.tomb[c][id]; items.push({ k: c + '~' + ek(id), v: { _u: ts, _s: SV, x: 1 }, ok: function () { (c0.rt[c] = c0.rt[c] || {})[id] = ts; } }); });
      });
      if (ch.set) items.push({ k: 'set', v: { _u: ch.set.u, _s: SV, j: JSON.stringify(ch.set.v) }, ok: function () { c0.rs = ch.set.u; } });
      if (ch.seq !== null) items.push({ k: 'seq', v: { _u: ch.seq, _s: SV, n: ch.seq }, ok: function () { c0.rq = ch.seq; } });
      for (var i = 0; i < items.length; i += CHUNK) {
        var part = items.slice(i, i + CHUNK), body = {};
        part.forEach(function (it) { body[it.k] = it.v; });
        var r = await J('PATCH', url('r'), body);
        if (r.status < 200 || r.status >= 300) throw fail(r, 'push');
        part.forEach(function (it) { it.ok(); });
      }
      var p = await J('PUT', url('ping'), { by: o.dev, _s: SV });
      if (p.status < 200 || p.status >= 300) throw fail(p, 'ping');
      return items.length;
    };

    /* ---------- دورة كاملة: ختم ← سحب ← دفع ---------- */
    self.sync = async function () {
      if (busy) return { busy: 1, pulled: 0, pushed: 0 };
      busy = 1;
      try {
        var t = now(); SC.stamp(db(), t);
        var a = await self.pull();
        SC.stamp(db(), now());
        var b = await self.push();
        return { pulled: a, pushed: b };
      } finally { busy = 0; }
    };
    self.busy = function () { return !!busy; };
    self.pingUrl = function () { return url('ping'); };
  }

  /* ============================== Google Drive ============================== */
  var GG = { dev: 'https://oauth2.googleapis.com/device/code', tok: 'https://oauth2.googleapis.com/token', api: 'https://www.googleapis.com/drive/v3', up: 'https://www.googleapis.com/upload/drive/v3', scope: 'https://www.googleapis.com/auth/drive.appdata' };
  var form = function (o) { return Object.keys(o).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(o[k]); }).join('&'); };

  function Drive(o) {
    var G = Object.assign({}, GG, o.g || {}), self = this, http = o.http, now = o.now || Date.now, busy = 0;
    var sid = o.sid || shopId(o.code), pre = 'tasyir-' + sid.slice(0, 12) + '-', mine = pre + o.dev + '.json';
    var st = function () { return o.store.get() || {}; };
    var put = function (x) { o.store.set(Object.assign(st(), x)); };
    var post = function (u, b) { return http({ method: 'POST', url: u, headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form(b) }); };

    /* --- تسجيل الدخول: device flow (لا يحتاج متصفحًا داخل التطبيق ولا عنوان إعادة توجيه) --- */
    self.begin = async function () {
      if (!o.cfg.clientId || !o.cfg.clientSecret) throw new Error('no-client');
      var r = await post(G.dev, { client_id: o.cfg.clientId, scope: G.scope }), j = jp(r.text, {});
      if (r.status !== 200 || !j.device_code) throw new Error(j.error_description || j.error || ('HTTP ' + r.status));
      return { device_code: j.device_code, user_code: j.user_code, url: j.verification_url || j.verification_uri || 'https://www.google.com/device', interval: Math.max(3, +j.interval || 5), expires: now() + (+j.expires_in || 600) * 1000 };
    };
    /* يعيد 'pending' | 'ok' ، ويرمي عند الخطأ/الرفض/الانتهاء */
    self.poll = async function (a) {
      if (now() > a.expires) throw new Error('expired');
      var r = await post(G.tok, { client_id: o.cfg.clientId, client_secret: o.cfg.clientSecret, device_code: a.device_code, grant_type: 'urn:ietf:params:oauth:grant-type:device_code' }), j = jp(r.text, {});
      if (r.status === 200 && j.refresh_token) { put({ rt: j.refresh_token, at: j.access_token, exp: now() + (+j.expires_in || 3600) * 1000 - 60000 }); return 'ok'; }
      if (j.error === 'authorization_pending' || j.error === 'slow_down') return 'pending';
      throw new Error(j.error_description || j.error || ('HTTP ' + r.status));
    };
    self.connected = function () { return !!st().rt; };
    self.disconnect = function () { o.store.set({}); };
    async function token() {
      var s = st(); if (!s.rt) throw new Error('not-connected');
      if (s.at && s.exp > now()) return s.at;
      var r = await post(G.tok, { client_id: o.cfg.clientId, client_secret: o.cfg.clientSecret, refresh_token: s.rt, grant_type: 'refresh_token' }), j = jp(r.text, {});
      if (r.status !== 200 || !j.access_token) {
        if (j.error === 'invalid_grant') { o.store.set({}); throw new Error('revoked'); }
        throw new Error(r.status ? (j.error || 'HTTP ' + r.status) : 'network');
      }
      put({ at: j.access_token, exp: now() + (+j.expires_in || 3600) * 1000 - 60000 }); return j.access_token;
    }
    var api = async function (m, u, body, ct) {
      var t = await token(), h = { Authorization: 'Bearer ' + t }; if (ct) h['Content-Type'] = ct;
      var r = await http({ method: m, url: u, headers: h, body: body });
      if (r.status === 401) { put({ at: '', exp: 0 }); t = await token(); h.Authorization = 'Bearer ' + t; r = await http({ method: m, url: u, headers: h, body: body }); }
      if (r.status < 200 || r.status >= 300) throw new Error(r.status ? 'drive HTTP ' + r.status : 'network');
      return r.text;
    };

    function snapshot() {
      var d = o.db(); SC.stamp(d, now());
      var ch = SC.collect(d, 0); return { v: 1, dev: o.dev, ts: now(), ch: ch };
    }
    /* force: ارفع لقطتي الآن حتى لو لم تتغير البيانات؛ gap: أقل فاصل بين رفعين (ms) */
    self.sync = async function (opt) {
      opt = opt || {}; if (busy) return { busy: 1, merged: 0, uploaded: 0 };
      busy = 1;
      try {
        var q = G.api + '/files?spaces=appDataFolder&pageSize=1000&fields=' + encodeURIComponent('files(id,name,modifiedTime)');
        var list = (jp(await api('GET', q), {}).files || []).filter(function (f) { return f.name.indexOf(pre) === 0; })
          .sort(function (x, y) { return x.modifiedTime < y.modifiedTime ? 1 : x.modifiedTime > y.modifiedTime ? -1 : 0; }); // الأحدث أولًا
        var seen = st().seen || {}, nseen = {}, merged = 0, mineOld = [], newest = {};
        list.forEach(function (f) { if (f.name === mine) mineOld.push(f); else if (!newest[f.name]) newest[f.name] = f; });
        for (var nm in newest) {
          var f = newest[nm];
          if (seen[f.id] !== f.modifiedTime) {
            var snap = jp(await api('GET', G.api + '/files/' + f.id + '?alt=media'), null);
            if (snap && snap.ch) { var r = SC.peerApply(o.db(), snap.ch, now()); merged += Object.keys(r.applied).length; }
          }
          nseen[f.id] = f.modifiedTime;
        }
        put({ seen: nseen });
        var sn = snapshot(), fpr = SC.fp(sn.ch), s2 = st(), up = 0;
        var due = !s2.lastUp || now() - s2.lastUp >= (opt.gap || 0);
        if (opt.force || (fpr !== s2.upfp && due)) {
          /* لا نستعمل PATCH (غير مدعوم في HttpURLConnection بأندرويد): ننشئ ملفًا جديدًا ثم نحذف القديم */
          var body = JSON.stringify(sn), b = 'tsr' + now().toString(36), meta = JSON.stringify({ name: mine, parents: ['appDataFolder'], mimeType: 'application/json' });
          await api('POST', G.up + '/files?uploadType=multipart', '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + meta + '\r\n--' + b + '\r\nContent-Type: application/json\r\n\r\n' + body + '\r\n--' + b + '--', 'multipart/related; boundary=' + b);
          put({ upfp: fpr, lastUp: now() }); up = 1;
          for (var i = 0; i < mineOld.length; i++) { try { await api('DELETE', G.api + '/files/' + mineOld[i].id); } catch (e) { /* يُنظَّف لاحقًا */ } }
        } else { for (var j = 1; j < mineOld.length; j++) { try { await api('DELETE', G.api + '/files/' + mineOld[j].id); } catch (e) { /* لا شيء */ } } }
        return { merged: merged, uploaded: up, files: list.length };
      } finally { busy = 0; }
    };
    self.busy = function () { return !!busy; };
  }

  return { shopId: shopId, ek: ek, dk: dk, Firebase: Firebase, Drive: Drive, G: GG, PAGE: PAGE, CHUNK: CHUNK };
});
