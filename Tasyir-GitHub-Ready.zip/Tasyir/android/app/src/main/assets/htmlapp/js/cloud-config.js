/* إعدادات السحابة الافتراضية (يمكن تعديلها هنا قبل البناء، أو من داخل التطبيق: الإعدادات ← المزامنة السحابية ← متقدّم).
   fb            : رابط Realtime Database (نفس مشروع Firebase الحالي لميزة «متابعة متجر»).
   gClientId/Secret : OAuth client من نوع "TVs and Limited Input devices" في Google Cloud (لمزامنة Google Drive). اتركهما فارغين لتعطيل Drive. */
window.TASYIR_CLOUD = {
  fb: 'https://tasyir-bmd-default-rtdb.europe-west1.firebasedatabase.app',
  gClientId: '',
  gClientSecret: ''
};
